export default function Loading() {
  return <p className="w-full h-lvh bg-amber-400">Loading...</p>;
}